OpenJDK 8 Linux builds
======================

[![travis](https://travis-ci.org/ojdkbuild/contrib_jdk8u-ci.svg?branch=jdk8u242-b08)](https://travis-ci.org/ojdkbuild/contrib_jdk8u-ci/builds)

OpenJDK 8 "vanilla" builds done on Travis CI - [downloads](https://github.com/ojdkbuild/contrib_jdk8u-ci/releases).

Builds are done in CentOS 6 containers for better compatibility with various Linux distributions.

License information
-------------------

OpenJDK binaries are released under the [GNU GPL v. 2 with classpath exception](https://github.com/ojdkbuild/contrib_jdk8u-ci/blob/master/LICENSE).

